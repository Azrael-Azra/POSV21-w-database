﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS_System
{
    public partial class SalesReport : Form
    {
        //Add database context
        databasePOS db;

        //Variable Declaration
        int currentIndex;
        public SalesReport()
        {
            InitializeComponent();
            cmb_searchBY.SelectedIndex = 0;
        }

        private void getSalesReport()
        {
            //Instantiate database
            db = new databasePOS();

            //Clears datagridview data
            dgv_showData.DataSource = null;

            //Add headertext
            dgv_showData.DataSource = db.showTransaction();
            dgv_showData.Columns[0].HeaderText = "Transaction Number";
            dgv_showData.Columns[1].HeaderText = "Employee ID";
            dgv_showData.Columns[2].HeaderText = "Date";
            dgv_showData.Columns[3].HeaderText = "Amount to Pay";
            dgv_showData.Columns[4].HeaderText = "Amount Tendered";
            dgv_showData.Columns[5].HeaderText = "Change";
            double totalPrice = 0;
            foreach (DataGridViewRow row in dgv_showData.Rows)
            {
                if (!row.IsNewRow)
                {
                    object value = row.Cells[3].Value;

                    if (value != null && double.TryParse(value.ToString(), out double price))
                    {
                        totalPrice += price;
                    }
                }
            }

            lbl_totalSales.Text = "P" + totalPrice.ToString("0.00");
        }

        private void SalesReport_Load(object sender, EventArgs e)
        {
            getSalesReport();
        }

        private void dgv_showData_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            db = new databasePOS();

            if (e.RowIndex >= 0)
            {
                currentIndex = int.Parse(dgv_showData.Rows[e.RowIndex].Cells[0].Value.ToString());

                var transaction = db.tblTransactions.FirstOrDefault(u => u.Transaction_ID == currentIndex);

                if (transaction != null)
                {
                    lbl_transactionID.Text = transaction.Transaction_ID.ToString();
                    lbl_employeeID.Text = transaction.ID.ToString();
                }
            }
        }

        //show transaction details
        private void btnView_Click(object sender, EventArgs e)
        {
            db = new databasePOS();



            var selectedTransaction = db.showTransactionDetails().Where(u => u.Transaction_ID == currentIndex).ToList();

            if (lbl_employeeID.Text != "--")
            {
                if (selectedTransaction != null)
                {
                    pnl_search.Hide();
                    dgv_showDetails.Show();

                    dgv_showDetails.DataSource = null;

                    dgv_showDetails.DataSource = selectedTransaction;
                    btn_showTransactions.Show();
                    pnl_date2.Hide();

                    double totalPrice = 0;

                    foreach (DataGridViewRow row in dgv_showDetails.Rows)
                    {
                        object value = row.Cells[3].Value;

                        if (value != null && double.TryParse(value.ToString(),out double price))
                        {
                            totalPrice += price;
                        }
                    }

                    lbl_totalSales.Text = "P" + totalPrice.ToString("0.00");


                }
            }

            


        }

        private void btn_showTransactions_Click(object sender, EventArgs e)
        {
            dgv_showDetails.DataSource = null;
            dgv_showDetails.Hide();
            getSalesReport();
            pnl_date2.Show();
            pnl_search.Show();
        }

        //Search by Category
        private void txtPaidInCash_TextChanged(object sender, EventArgs e)
        {
            db = new databasePOS();

            if (!string.IsNullOrWhiteSpace(tb_search.Text.Trim()))
            {
                switch (cmb_searchBY.SelectedIndex)
                {
                    //search by transactionID
                    case 0:
                        dgv_showData.DataSource = null;
                        dgv_showData.DataSource = db.searchedSalesReport(int.Parse(tb_search.Text.Trim()));
                        dgv_showData.Columns[1].HeaderText = "Employee ID";
                        break;
                    //search by epmloyee number
                    case 1:
                        dgv_showData.DataSource = null;
                        dgv_showData.DataSource = db.searchedSalesReportByUserID(int.Parse(tb_search.Text.Trim()));
                        dgv_showData.Columns[1].HeaderText = "Employee ID";
                        break;
                }
            }
            else
            {
                dgv_showData.DataSource = null;
                dgv_showData.DataSource = db.showTransaction();
                dgv_showData.Columns[1].HeaderText = "Employee ID";
            }
        }

        //sort by date
        private void btn_filterBYdate2_Click(object sender, EventArgs e)
        {
            db = new databasePOS();
            dgv_showData.DataSource = null;
            DateTime fromDate = FromDatePicker2.Value.Date;
            DateTime toDate = ToDatePicker2.Value.Date;

            var filter = db.showTransaction();
            var filteredData = filter.Where(t => t.DATE >= fromDate && t.DATE <= toDate).ToList();

            if (filteredData.Count > 0)
            {
                dgv_showData.DataSource = filteredData;

                double totalSales = 0;
                foreach (DataGridViewRow row in dgv_showData.Rows)
                {
                    object value = row.Cells[3].Value;

                    if (value != null && double.TryParse(value.ToString(),out double price))
                    {
                        totalSales += price;
                    }
                }
                lbl_totalSales.Text = "P" + totalSales.ToString("0.00");
            }
            else
            {
                lbl_totalSales.Text = "--";
            }
            
        }

        //Accepst digits only
        private void tb_search_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void FromDatePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dgv_showData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
