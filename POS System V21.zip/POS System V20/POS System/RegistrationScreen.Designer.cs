﻿namespace POS_System
{
    partial class RegistrationScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelChildform = new System.Windows.Forms.Panel();
            this.lblMName = new System.Windows.Forms.Label();
            this.tb_ins_middleName = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.lblLname = new System.Windows.Forms.Label();
            this.lblFname = new System.Windows.Forms.Label();
            this.lblRole = new System.Windows.Forms.Label();
            this.tb_ins_role = new ComponentFactory.Krypton.Toolkit.KryptonComboBox();
            this.pnlBorderline = new System.Windows.Forms.Panel();
            this.tb_ins_firstName = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.tb_ins_lastName = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.pbCheck3 = new System.Windows.Forms.PictureBox();
            this.pbCheck2 = new System.Windows.Forms.PictureBox();
            this.pbCheck1 = new System.Windows.Forms.PictureBox();
            this.lblDesc3 = new System.Windows.Forms.Label();
            this.lblDesc2 = new System.Windows.Forms.Label();
            this.lblDesc1 = new System.Windows.Forms.Label();
            this.lblDesc = new System.Windows.Forms.Label();
            this.pbImage = new System.Windows.Forms.PictureBox();
            this.lblheader = new System.Windows.Forms.Label();
            this.btnInstantRegister = new System.Windows.Forms.Button();
            this.panelChildform.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tb_ins_role)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCheck3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCheck2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCheck1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbImage)).BeginInit();
            this.SuspendLayout();
            // 
            // panelChildform
            // 
            this.panelChildform.BackColor = System.Drawing.Color.White;
            this.panelChildform.Controls.Add(this.lblMName);
            this.panelChildform.Controls.Add(this.tb_ins_middleName);
            this.panelChildform.Controls.Add(this.lblLname);
            this.panelChildform.Controls.Add(this.lblFname);
            this.panelChildform.Controls.Add(this.lblRole);
            this.panelChildform.Controls.Add(this.tb_ins_role);
            this.panelChildform.Controls.Add(this.pnlBorderline);
            this.panelChildform.Controls.Add(this.tb_ins_firstName);
            this.panelChildform.Controls.Add(this.tb_ins_lastName);
            this.panelChildform.Controls.Add(this.pbCheck3);
            this.panelChildform.Controls.Add(this.pbCheck2);
            this.panelChildform.Controls.Add(this.pbCheck1);
            this.panelChildform.Controls.Add(this.lblDesc3);
            this.panelChildform.Controls.Add(this.lblDesc2);
            this.panelChildform.Controls.Add(this.lblDesc1);
            this.panelChildform.Controls.Add(this.lblDesc);
            this.panelChildform.Controls.Add(this.pbImage);
            this.panelChildform.Controls.Add(this.lblheader);
            this.panelChildform.Controls.Add(this.btnInstantRegister);
            this.panelChildform.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelChildform.Font = new System.Drawing.Font("Inter SemiBold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panelChildform.Location = new System.Drawing.Point(0, 0);
            this.panelChildform.Name = "panelChildform";
            this.panelChildform.Size = new System.Drawing.Size(830, 529);
            this.panelChildform.TabIndex = 68;
            // 
            // lblMName
            // 
            this.lblMName.AutoSize = true;
            this.lblMName.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lblMName.Location = new System.Drawing.Point(334, 130);
            this.lblMName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMName.Name = "lblMName";
            this.lblMName.Size = new System.Drawing.Size(76, 16);
            this.lblMName.TabIndex = 71;
            this.lblMName.Text = "Middle Name";
            // 
            // tb_ins_middleName
            // 
            this.tb_ins_middleName.Location = new System.Drawing.Point(326, 139);
            this.tb_ins_middleName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tb_ins_middleName.MinimumSize = new System.Drawing.Size(0, 40);
            this.tb_ins_middleName.Name = "tb_ins_middleName";
            this.tb_ins_middleName.Size = new System.Drawing.Size(201, 41);
            this.tb_ins_middleName.StateActive.Back.Color1 = System.Drawing.Color.White;
            this.tb_ins_middleName.StateActive.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(100)))), ((int)(((byte)(100)))));
            this.tb_ins_middleName.StateActive.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.tb_ins_middleName.StateActive.Border.Rounding = 5;
            this.tb_ins_middleName.StateActive.Border.Width = 1;
            this.tb_ins_middleName.StateActive.Content.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.tb_ins_middleName.StateActive.Content.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_ins_middleName.StateActive.Content.Padding = new System.Windows.Forms.Padding(15, 10, 15, 10);
            this.tb_ins_middleName.StateNormal.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.tb_ins_middleName.StateNormal.Border.Rounding = 15;
            this.tb_ins_middleName.StateNormal.Content.Padding = new System.Windows.Forms.Padding(5);
            this.tb_ins_middleName.TabIndex = 70;
            // 
            // lblLname
            // 
            this.lblLname.AutoSize = true;
            this.lblLname.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLname.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lblLname.Location = new System.Drawing.Point(544, 72);
            this.lblLname.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLname.Name = "lblLname";
            this.lblLname.Size = new System.Drawing.Size(62, 16);
            this.lblLname.TabIndex = 69;
            this.lblLname.Text = "Last Name";
            // 
            // lblFname
            // 
            this.lblFname.AutoSize = true;
            this.lblFname.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFname.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lblFname.Location = new System.Drawing.Point(334, 72);
            this.lblFname.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFname.Name = "lblFname";
            this.lblFname.Size = new System.Drawing.Size(63, 16);
            this.lblFname.TabIndex = 68;
            this.lblFname.Text = "First Name";
            // 
            // lblRole
            // 
            this.lblRole.AutoSize = true;
            this.lblRole.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRole.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lblRole.Location = new System.Drawing.Point(544, 130);
            this.lblRole.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRole.Name = "lblRole";
            this.lblRole.Size = new System.Drawing.Size(30, 16);
            this.lblRole.TabIndex = 67;
            this.lblRole.Text = "Role";
            // 
            // tb_ins_role
            // 
            this.tb_ins_role.AutoCompleteCustomSource.AddRange(new string[] {
            "Administrator",
            "Employee"});
            this.tb_ins_role.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.tb_ins_role.DropDownWidth = 110;
            this.tb_ins_role.Items.AddRange(new object[] {
            "ADMIN",
            "EMPLOYEE"});
            this.tb_ins_role.Location = new System.Drawing.Point(536, 133);
            this.tb_ins_role.MinimumSize = new System.Drawing.Size(0, 47);
            this.tb_ins_role.Name = "tb_ins_role";
            this.tb_ins_role.Size = new System.Drawing.Size(159, 47);
            this.tb_ins_role.StateActive.ComboBox.Back.Color1 = System.Drawing.Color.White;
            this.tb_ins_role.StateActive.ComboBox.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(100)))), ((int)(((byte)(100)))));
            this.tb_ins_role.StateActive.ComboBox.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.tb_ins_role.StateActive.ComboBox.Border.Rounding = 5;
            this.tb_ins_role.StateActive.ComboBox.Content.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.tb_ins_role.StateActive.ComboBox.Content.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_ins_role.StateActive.ComboBox.Content.Padding = new System.Windows.Forms.Padding(15, 10, 15, 10);
            this.tb_ins_role.StateCommon.ComboBox.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.tb_ins_role.StateCommon.ComboBox.Content.Padding = new System.Windows.Forms.Padding(0);
            this.tb_ins_role.TabIndex = 49;
            // 
            // pnlBorderline
            // 
            this.pnlBorderline.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(52)))), ((int)(((byte)(52)))));
            this.pnlBorderline.Location = new System.Drawing.Point(324, 58);
            this.pnlBorderline.Name = "pnlBorderline";
            this.pnlBorderline.Size = new System.Drawing.Size(453, 1);
            this.pnlBorderline.TabIndex = 45;
            // 
            // tb_ins_firstName
            // 
            this.tb_ins_firstName.Location = new System.Drawing.Point(324, 81);
            this.tb_ins_firstName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tb_ins_firstName.MinimumSize = new System.Drawing.Size(0, 40);
            this.tb_ins_firstName.Name = "tb_ins_firstName";
            this.tb_ins_firstName.Size = new System.Drawing.Size(203, 41);
            this.tb_ins_firstName.StateActive.Back.Color1 = System.Drawing.Color.White;
            this.tb_ins_firstName.StateActive.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(100)))), ((int)(((byte)(100)))));
            this.tb_ins_firstName.StateActive.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.tb_ins_firstName.StateActive.Border.Rounding = 5;
            this.tb_ins_firstName.StateActive.Border.Width = 1;
            this.tb_ins_firstName.StateActive.Content.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.tb_ins_firstName.StateActive.Content.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_ins_firstName.StateActive.Content.Padding = new System.Windows.Forms.Padding(15, 10, 15, 10);
            this.tb_ins_firstName.StateNormal.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.tb_ins_firstName.StateNormal.Border.Rounding = 15;
            this.tb_ins_firstName.StateNormal.Content.Padding = new System.Windows.Forms.Padding(5);
            this.tb_ins_firstName.TabIndex = 42;
            // 
            // tb_ins_lastName
            // 
            this.tb_ins_lastName.Location = new System.Drawing.Point(536, 81);
            this.tb_ins_lastName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tb_ins_lastName.MinimumSize = new System.Drawing.Size(0, 40);
            this.tb_ins_lastName.Name = "tb_ins_lastName";
            this.tb_ins_lastName.Size = new System.Drawing.Size(241, 41);
            this.tb_ins_lastName.StateActive.Back.Color1 = System.Drawing.Color.White;
            this.tb_ins_lastName.StateActive.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(100)))), ((int)(((byte)(100)))));
            this.tb_ins_lastName.StateActive.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.tb_ins_lastName.StateActive.Border.Rounding = 5;
            this.tb_ins_lastName.StateActive.Border.Width = 1;
            this.tb_ins_lastName.StateActive.Content.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.tb_ins_lastName.StateActive.Content.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_ins_lastName.StateActive.Content.Padding = new System.Windows.Forms.Padding(15, 10, 15, 10);
            this.tb_ins_lastName.StateNormal.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.tb_ins_lastName.StateNormal.Border.Rounding = 15;
            this.tb_ins_lastName.StateNormal.Content.Padding = new System.Windows.Forms.Padding(5);
            this.tb_ins_lastName.TabIndex = 44;
            // 
            // pbCheck3
            // 
            this.pbCheck3.Image = global::POS_System.Properties.Resources.Check;
            this.pbCheck3.Location = new System.Drawing.Point(67, 377);
            this.pbCheck3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pbCheck3.Name = "pbCheck3";
            this.pbCheck3.Size = new System.Drawing.Size(12, 12);
            this.pbCheck3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbCheck3.TabIndex = 41;
            this.pbCheck3.TabStop = false;
            // 
            // pbCheck2
            // 
            this.pbCheck2.Image = global::POS_System.Properties.Resources.Check;
            this.pbCheck2.Location = new System.Drawing.Point(67, 346);
            this.pbCheck2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pbCheck2.Name = "pbCheck2";
            this.pbCheck2.Size = new System.Drawing.Size(12, 12);
            this.pbCheck2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbCheck2.TabIndex = 40;
            this.pbCheck2.TabStop = false;
            // 
            // pbCheck1
            // 
            this.pbCheck1.Image = global::POS_System.Properties.Resources.Check;
            this.pbCheck1.Location = new System.Drawing.Point(67, 312);
            this.pbCheck1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pbCheck1.Name = "pbCheck1";
            this.pbCheck1.Size = new System.Drawing.Size(12, 12);
            this.pbCheck1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbCheck1.TabIndex = 39;
            this.pbCheck1.TabStop = false;
            // 
            // lblDesc3
            // 
            this.lblDesc3.AutoSize = true;
            this.lblDesc3.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDesc3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblDesc3.Location = new System.Drawing.Point(84, 375);
            this.lblDesc3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDesc3.Name = "lblDesc3";
            this.lblDesc3.Size = new System.Drawing.Size(115, 17);
            this.lblDesc3.TabIndex = 38;
            this.lblDesc3.Text = "Account Managers";
            // 
            // lblDesc2
            // 
            this.lblDesc2.AutoSize = true;
            this.lblDesc2.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDesc2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblDesc2.Location = new System.Drawing.Point(84, 344);
            this.lblDesc2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDesc2.Name = "lblDesc2";
            this.lblDesc2.Size = new System.Drawing.Size(115, 17);
            this.lblDesc2.TabIndex = 37;
            this.lblDesc2.Text = "Washup Protection";
            // 
            // lblDesc1
            // 
            this.lblDesc1.AutoSize = true;
            this.lblDesc1.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDesc1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblDesc1.Location = new System.Drawing.Point(84, 311);
            this.lblDesc1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDesc1.Name = "lblDesc1";
            this.lblDesc1.Size = new System.Drawing.Size(150, 17);
            this.lblDesc1.TabIndex = 36;
            this.lblDesc1.Text = "Highly Trained Assistants";
            // 
            // lblDesc
            // 
            this.lblDesc.AutoSize = true;
            this.lblDesc.Font = new System.Drawing.Font("Inter", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDesc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lblDesc.Location = new System.Drawing.Point(62, 274);
            this.lblDesc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDesc.Name = "lblDesc";
            this.lblDesc.Size = new System.Drawing.Size(166, 23);
            this.lblDesc.TabIndex = 35;
            this.lblDesc.Text = "Add Your Employee";
            // 
            // pbImage
            // 
            this.pbImage.Image = global::POS_System.Properties.Resources._5282910_1;
            this.pbImage.Location = new System.Drawing.Point(55, 28);
            this.pbImage.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pbImage.Name = "pbImage";
            this.pbImage.Size = new System.Drawing.Size(221, 211);
            this.pbImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbImage.TabIndex = 34;
            this.pbImage.TabStop = false;
            // 
            // lblheader
            // 
            this.lblheader.AutoSize = true;
            this.lblheader.Font = new System.Drawing.Font("Inter", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblheader.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lblheader.Location = new System.Drawing.Point(320, 28);
            this.lblheader.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblheader.Name = "lblheader";
            this.lblheader.Size = new System.Drawing.Size(100, 23);
            this.lblheader.TabIndex = 3;
            this.lblheader.Text = "Get Started";
            // 
            // btnInstantRegister
            // 
            this.btnInstantRegister.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(41)))), ((int)(((byte)(48)))));
            this.btnInstantRegister.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(41)))), ((int)(((byte)(48)))));
            this.btnInstantRegister.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInstantRegister.Font = new System.Drawing.Font("Inter", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInstantRegister.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnInstantRegister.Location = new System.Drawing.Point(324, 203);
            this.btnInstantRegister.Name = "btnInstantRegister";
            this.btnInstantRegister.Size = new System.Drawing.Size(453, 40);
            this.btnInstantRegister.TabIndex = 29;
            this.btnInstantRegister.Text = "Instant Register";
            this.btnInstantRegister.UseVisualStyleBackColor = false;
            this.btnInstantRegister.Click += new System.EventHandler(this.button2_Click);
            // 
            // RegistrationScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ClientSize = new System.Drawing.Size(830, 529);
            this.Controls.Add(this.panelChildform);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "RegistrationScreen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RegistrationScreen";
            this.panelChildform.ResumeLayout(false);
            this.panelChildform.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tb_ins_role)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCheck3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCheck2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCheck1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbImage)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelChildform;
        private System.Windows.Forms.Button btnInstantRegister;
        private System.Windows.Forms.Label lblheader;
        private System.Windows.Forms.PictureBox pbCheck3;
        private System.Windows.Forms.PictureBox pbCheck2;
        private System.Windows.Forms.PictureBox pbCheck1;
        private System.Windows.Forms.Label lblDesc3;
        private System.Windows.Forms.Label lblDesc2;
        private System.Windows.Forms.Label lblDesc1;
        private System.Windows.Forms.Label lblDesc;
        private System.Windows.Forms.PictureBox pbImage;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox tb_ins_firstName;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox tb_ins_lastName;
        private ComponentFactory.Krypton.Toolkit.KryptonComboBox tb_ins_role;
        private System.Windows.Forms.Panel pnlBorderline;
        private System.Windows.Forms.Label lblRole;
        private System.Windows.Forms.Label lblLname;
        private System.Windows.Forms.Label lblFname;
        private System.Windows.Forms.Label lblMName;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox tb_ins_middleName;
    }
}