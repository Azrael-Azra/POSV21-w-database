﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS_System
{
    public partial class ScreenLoad : Form
    {
        int sec = 0;
        public ScreenLoad()
        {
            InitializeComponent();
            tmrAnimation.Start();
            
        }

        //animation
        private void timer1_Tick(object sender, EventArgs e)
        {
            sec++;
            if (sec == 3)
            {
                new Login().Show();
                this.Hide();
                tmrAnimation.Stop();
            }
        }
    }
}
