﻿namespace POS_System
{
    partial class POS_System
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dgvProducts = new System.Windows.Forms.DataGridView();
            this.clmn_Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmn_Product = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmn_Qty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmn_Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmn_Category = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Subtotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblHeader = new System.Windows.Forms.Label();
            this.lblCategoryHeader = new System.Windows.Forms.Label();
            this.btnMeat = new System.Windows.Forms.Button();
            this.lblItemsHeader = new System.Windows.Forms.Label();
            this.btnFood = new System.Windows.Forms.Button();
            this.btnDrinks = new System.Windows.Forms.Button();
            this.btnSnacks = new System.Windows.Forms.Button();
            this.flowpnlProducts = new System.Windows.Forms.FlowLayoutPanel();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblCash = new System.Windows.Forms.Label();
            this.lblChange = new System.Windows.Forms.Label();
            this.lblItemDetail = new System.Windows.Forms.Label();
            this.lblItemId = new System.Windows.Forms.Label();
            this.lblItemID_ = new System.Windows.Forms.Label();
            this.pnlItems = new System.Windows.Forms.Panel();
            this.lblChangeAmt = new System.Windows.Forms.Label();
            this.lbl_total = new System.Windows.Forms.Label();
            this.txtPaidInCash = new System.Windows.Forms.TextBox();
            this.btnSaveReceipt = new System.Windows.Forms.Button();
            this.btn_void = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.dgv_receipt = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label9 = new System.Windows.Forms.Label();
            this.lbl_receiptTotal = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btnNewTransc = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.lbl_receiptAmountTendered = new System.Windows.Forms.Label();
            this.lbl_receiptChanged = new System.Windows.Forms.Label();
            this.pnlReceipt = new System.Windows.Forms.Panel();
            this.lbl_date = new System.Windows.Forms.Label();
            this.lbl_userID = new System.Windows.Forms.Label();
            this.lbl_transactionNumber = new System.Windows.Forms.Label();
            this.btn_All = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProducts)).BeginInit();
            this.pnlItems.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_receipt)).BeginInit();
            this.pnlReceipt.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvProducts
            // 
            this.dgvProducts.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.dgvProducts.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvProducts.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(246)))), ((int)(((byte)(248)))));
            this.dgvProducts.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvProducts.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(58)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Inter", 6F);
            dataGridViewCellStyle19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvProducts.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle19;
            this.dgvProducts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProducts.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clmn_Id,
            this.clmn_Product,
            this.clmn_Qty,
            this.clmn_Price,
            this.clmn_Category,
            this.Subtotal});
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle20.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Inter", 6F);
            dataGridViewCellStyle20.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvProducts.DefaultCellStyle = dataGridViewCellStyle20;
            this.dgvProducts.Location = new System.Drawing.Point(6, 27);
            this.dgvProducts.Name = "dgvProducts";
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle21.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Inter", 6F);
            dataGridViewCellStyle21.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvProducts.RowHeadersDefaultCellStyle = dataGridViewCellStyle21;
            this.dgvProducts.RowHeadersWidth = 25;
            this.dgvProducts.Size = new System.Drawing.Size(290, 239);
            this.dgvProducts.TabIndex = 49;
            this.dgvProducts.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvProducts_CellClick);
            this.dgvProducts.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvProducts_CellValueChanged);
            // 
            // clmn_Id
            // 
            this.clmn_Id.FillWeight = 56.29122F;
            this.clmn_Id.HeaderText = "ID";
            this.clmn_Id.MinimumWidth = 6;
            this.clmn_Id.Name = "clmn_Id";
            // 
            // clmn_Product
            // 
            this.clmn_Product.FillWeight = 135.7303F;
            this.clmn_Product.HeaderText = "Product";
            this.clmn_Product.MinimumWidth = 6;
            this.clmn_Product.Name = "clmn_Product";
            // 
            // clmn_Qty
            // 
            this.clmn_Qty.FillWeight = 80.21391F;
            this.clmn_Qty.HeaderText = "Qty";
            this.clmn_Qty.MinimumWidth = 6;
            this.clmn_Qty.Name = "clmn_Qty";
            // 
            // clmn_Price
            // 
            this.clmn_Price.FillWeight = 91.15051F;
            this.clmn_Price.HeaderText = "Price";
            this.clmn_Price.MinimumWidth = 6;
            this.clmn_Price.Name = "clmn_Price";
            // 
            // clmn_Category
            // 
            this.clmn_Category.FillWeight = 136.6141F;
            this.clmn_Category.HeaderText = "Category";
            this.clmn_Category.MinimumWidth = 6;
            this.clmn_Category.Name = "clmn_Category";
            // 
            // Subtotal
            // 
            this.Subtotal.HeaderText = "Subtotal";
            this.Subtotal.MinimumWidth = 6;
            this.Subtotal.Name = "Subtotal";
            // 
            // lblHeader
            // 
            this.lblHeader.AutoSize = true;
            this.lblHeader.Font = new System.Drawing.Font("Inter", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeader.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lblHeader.Location = new System.Drawing.Point(37, 39);
            this.lblHeader.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(116, 23);
            this.lblHeader.TabIndex = 5;
            this.lblHeader.Text = "Point of Sales";
            // 
            // lblCategoryHeader
            // 
            this.lblCategoryHeader.AutoSize = true;
            this.lblCategoryHeader.Font = new System.Drawing.Font("Inter", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCategoryHeader.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblCategoryHeader.Location = new System.Drawing.Point(356, 70);
            this.lblCategoryHeader.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCategoryHeader.Name = "lblCategoryHeader";
            this.lblCategoryHeader.Size = new System.Drawing.Size(73, 21);
            this.lblCategoryHeader.TabIndex = 46;
            this.lblCategoryHeader.Text = "Category";
            // 
            // btnMeat
            // 
            this.btnMeat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(101)))), ((int)(((byte)(67)))));
            this.btnMeat.FlatAppearance.BorderSize = 0;
            this.btnMeat.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(121)))), ((int)(((byte)(87)))));
            this.btnMeat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMeat.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMeat.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.btnMeat.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnMeat.Location = new System.Drawing.Point(444, 98);
            this.btnMeat.Name = "btnMeat";
            this.btnMeat.Size = new System.Drawing.Size(78, 57);
            this.btnMeat.TabIndex = 55;
            this.btnMeat.Text = "Meat";
            this.btnMeat.UseVisualStyleBackColor = false;
            this.btnMeat.Click += new System.EventHandler(this.btnMeat_Click);
            // 
            // lblItemsHeader
            // 
            this.lblItemsHeader.AutoSize = true;
            this.lblItemsHeader.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemsHeader.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblItemsHeader.Location = new System.Drawing.Point(4, 5);
            this.lblItemsHeader.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblItemsHeader.Name = "lblItemsHeader";
            this.lblItemsHeader.Size = new System.Drawing.Size(40, 17);
            this.lblItemsHeader.TabIndex = 56;
            this.lblItemsHeader.Text = "Items";
            // 
            // btnFood
            // 
            this.btnFood.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(168)))), ((int)(((byte)(54)))));
            this.btnFood.FlatAppearance.BorderSize = 0;
            this.btnFood.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(188)))), ((int)(((byte)(74)))));
            this.btnFood.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFood.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFood.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.btnFood.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnFood.Location = new System.Drawing.Point(528, 98);
            this.btnFood.Name = "btnFood";
            this.btnFood.Size = new System.Drawing.Size(78, 57);
            this.btnFood.TabIndex = 57;
            this.btnFood.Text = "Food";
            this.btnFood.UseVisualStyleBackColor = false;
            this.btnFood.Click += new System.EventHandler(this.btnFood_Click);
            // 
            // btnDrinks
            // 
            this.btnDrinks.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(143)))), ((int)(((byte)(161)))), ((int)(((byte)(242)))));
            this.btnDrinks.FlatAppearance.BorderSize = 0;
            this.btnDrinks.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(181)))), ((int)(((byte)(252)))));
            this.btnDrinks.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDrinks.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDrinks.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.btnDrinks.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnDrinks.Location = new System.Drawing.Point(616, 98);
            this.btnDrinks.Name = "btnDrinks";
            this.btnDrinks.Size = new System.Drawing.Size(78, 57);
            this.btnDrinks.TabIndex = 58;
            this.btnDrinks.Text = "Drinks";
            this.btnDrinks.UseVisualStyleBackColor = false;
            this.btnDrinks.Click += new System.EventHandler(this.btnDrinks_Click);
            // 
            // btnSnacks
            // 
            this.btnSnacks.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(170)))), ((int)(((byte)(107)))));
            this.btnSnacks.FlatAppearance.BorderSize = 0;
            this.btnSnacks.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(190)))), ((int)(((byte)(127)))));
            this.btnSnacks.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSnacks.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSnacks.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.btnSnacks.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnSnacks.Location = new System.Drawing.Point(700, 98);
            this.btnSnacks.Name = "btnSnacks";
            this.btnSnacks.Size = new System.Drawing.Size(78, 57);
            this.btnSnacks.TabIndex = 59;
            this.btnSnacks.Text = "Snacks";
            this.btnSnacks.UseVisualStyleBackColor = false;
            this.btnSnacks.Click += new System.EventHandler(this.btnAddons_Click);
            // 
            // flowpnlProducts
            // 
            this.flowpnlProducts.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flowpnlProducts.AutoScroll = true;
            this.flowpnlProducts.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(241)))), ((int)(((byte)(241)))));
            this.flowpnlProducts.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowpnlProducts.Location = new System.Drawing.Point(360, 173);
            this.flowpnlProducts.Name = "flowpnlProducts";
            this.flowpnlProducts.Size = new System.Drawing.Size(427, 236);
            this.flowpnlProducts.TabIndex = 60;
            // 
            // lblTotal
            // 
            this.lblTotal.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(34)))), ((int)(((byte)(34)))));
            this.lblTotal.Location = new System.Drawing.Point(16, 278);
            this.lblTotal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(88, 17);
            this.lblTotal.TabIndex = 63;
            this.lblTotal.Text = "Total Amount:";
            // 
            // lblCash
            // 
            this.lblCash.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblCash.AutoSize = true;
            this.lblCash.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCash.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(34)))), ((int)(((byte)(34)))));
            this.lblCash.Location = new System.Drawing.Point(17, 302);
            this.lblCash.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCash.Name = "lblCash";
            this.lblCash.Size = new System.Drawing.Size(75, 16);
            this.lblCash.TabIndex = 64;
            this.lblCash.Text = "Paid in Cash:";
            // 
            // lblChange
            // 
            this.lblChange.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblChange.AutoSize = true;
            this.lblChange.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChange.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(34)))), ((int)(((byte)(34)))));
            this.lblChange.Location = new System.Drawing.Point(17, 322);
            this.lblChange.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblChange.Name = "lblChange";
            this.lblChange.Size = new System.Drawing.Size(50, 16);
            this.lblChange.TabIndex = 65;
            this.lblChange.Text = "Change:";
            // 
            // lblItemDetail
            // 
            this.lblItemDetail.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblItemDetail.AutoSize = true;
            this.lblItemDetail.Font = new System.Drawing.Font("Inter", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemDetail.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblItemDetail.Location = new System.Drawing.Point(469, 416);
            this.lblItemDetail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblItemDetail.Name = "lblItemDetail";
            this.lblItemDetail.Size = new System.Drawing.Size(82, 21);
            this.lblItemDetail.TabIndex = 66;
            this.lblItemDetail.Text = "Item Detail";
            // 
            // lblItemId
            // 
            this.lblItemId.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblItemId.AutoSize = true;
            this.lblItemId.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemId.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(34)))), ((int)(((byte)(34)))));
            this.lblItemId.Location = new System.Drawing.Point(494, 442);
            this.lblItemId.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblItemId.Name = "lblItemId";
            this.lblItemId.Size = new System.Drawing.Size(44, 16);
            this.lblItemId.TabIndex = 67;
            this.lblItemId.Text = "ItemID:";
            // 
            // lblItemID_
            // 
            this.lblItemID_.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblItemID_.AutoSize = true;
            this.lblItemID_.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemID_.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(34)))), ((int)(((byte)(34)))));
            this.lblItemID_.Location = new System.Drawing.Point(551, 442);
            this.lblItemID_.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblItemID_.Name = "lblItemID_";
            this.lblItemID_.Size = new System.Drawing.Size(42, 16);
            this.lblItemID_.TabIndex = 70;
            this.lblItemID_.Text = "00000";
            // 
            // pnlItems
            // 
            this.pnlItems.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlItems.BackColor = System.Drawing.Color.White;
            this.pnlItems.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlItems.Controls.Add(this.lblChangeAmt);
            this.pnlItems.Controls.Add(this.lbl_total);
            this.pnlItems.Controls.Add(this.txtPaidInCash);
            this.pnlItems.Controls.Add(this.lblChange);
            this.pnlItems.Controls.Add(this.lblCash);
            this.pnlItems.Controls.Add(this.lblTotal);
            this.pnlItems.Controls.Add(this.lblItemsHeader);
            this.pnlItems.Controls.Add(this.dgvProducts);
            this.pnlItems.Controls.Add(this.btnSaveReceipt);
            this.pnlItems.Location = new System.Drawing.Point(40, 70);
            this.pnlItems.Name = "pnlItems";
            this.pnlItems.Size = new System.Drawing.Size(304, 398);
            this.pnlItems.TabIndex = 72;
            // 
            // lblChangeAmt
            // 
            this.lblChangeAmt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblChangeAmt.AutoSize = true;
            this.lblChangeAmt.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChangeAmt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(34)))), ((int)(((byte)(34)))));
            this.lblChangeAmt.Location = new System.Drawing.Point(112, 323);
            this.lblChangeAmt.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblChangeAmt.Name = "lblChangeAmt";
            this.lblChangeAmt.Size = new System.Drawing.Size(15, 13);
            this.lblChangeAmt.TabIndex = 75;
            this.lblChangeAmt.Text = "--";
            // 
            // lbl_total
            // 
            this.lbl_total.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbl_total.AutoSize = true;
            this.lbl_total.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_total.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(34)))), ((int)(((byte)(34)))));
            this.lbl_total.Location = new System.Drawing.Point(112, 278);
            this.lbl_total.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_total.Name = "lbl_total";
            this.lbl_total.Size = new System.Drawing.Size(20, 17);
            this.lbl_total.TabIndex = 74;
            this.lbl_total.Text = "--";
            // 
            // txtPaidInCash
            // 
            this.txtPaidInCash.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtPaidInCash.BackColor = System.Drawing.Color.White;
            this.txtPaidInCash.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPaidInCash.Location = new System.Drawing.Point(115, 300);
            this.txtPaidInCash.Name = "txtPaidInCash";
            this.txtPaidInCash.Size = new System.Drawing.Size(158, 20);
            this.txtPaidInCash.TabIndex = 73;
            this.txtPaidInCash.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtPaidInCash_KeyDown);
            this.txtPaidInCash.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPaidInCash_KeyPress);
            // 
            // btnSaveReceipt
            // 
            this.btnSaveReceipt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnSaveReceipt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(129)))), ((int)(((byte)(118)))));
            this.btnSaveReceipt.FlatAppearance.BorderSize = 0;
            this.btnSaveReceipt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSaveReceipt.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveReceipt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.btnSaveReceipt.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSaveReceipt.Location = new System.Drawing.Point(19, 349);
            this.btnSaveReceipt.Name = "btnSaveReceipt";
            this.btnSaveReceipt.Padding = new System.Windows.Forms.Padding(40, 0, 60, 0);
            this.btnSaveReceipt.Size = new System.Drawing.Size(254, 38);
            this.btnSaveReceipt.TabIndex = 48;
            this.btnSaveReceipt.Text = "Place Order";
            this.btnSaveReceipt.UseVisualStyleBackColor = false;
            this.btnSaveReceipt.Click += new System.EventHandler(this.btnSaveReceipt_Click);
            // 
            // btn_void
            // 
            this.btn_void.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_void.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(69)))), ((int)(((byte)(69)))));
            this.btn_void.FlatAppearance.BorderSize = 0;
            this.btn_void.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_void.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_void.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.btn_void.Image = global::POS_System.Properties.Resources.delete__1_;
            this.btn_void.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_void.Location = new System.Drawing.Point(616, 424);
            this.btn_void.Name = "btn_void";
            this.btn_void.Padding = new System.Windows.Forms.Padding(10, 0, 40, 0);
            this.btn_void.Size = new System.Drawing.Size(171, 34);
            this.btn_void.TabIndex = 76;
            this.btn_void.Text = "Void Item";
            this.btn_void.UseVisualStyleBackColor = false;
            this.btn_void.Click += new System.EventHandler(this.btn_void_Click);
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Inter", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.label2.Location = new System.Drawing.Point(144, 15);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 12);
            this.label2.TabIndex = 7;
            this.label2.Text = "SALES RECEIPT";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Inter", 5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.label3.Location = new System.Drawing.Point(130, 47);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 10);
            this.label3.TabIndex = 8;
            this.label3.Text = "Asian College of Technology";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.label1.Location = new System.Drawing.Point(111, 29);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(152, 17);
            this.label1.TabIndex = 6;
            this.label1.Text = "ELYSIUM CORPORATION";
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Inter", 5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.label4.Location = new System.Drawing.Point(145, 59);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 10);
            this.label4.TabIndex = 9;
            this.label4.Text = "Batch 2024-2025";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Inter", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.label5.Location = new System.Drawing.Point(17, 88);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(107, 14);
            this.label5.TabIndex = 10;
            this.label5.Text = "Transaction Number:\r\n";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Inter", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.label6.Location = new System.Drawing.Point(17, 102);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 14);
            this.label6.TabIndex = 11;
            this.label6.Text = "Employee ID:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Inter", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.label7.Location = new System.Drawing.Point(17, 124);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(103, 14);
            this.label7.TabIndex = 12;
            this.label7.Text = "Transaction Details";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Inter", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.label8.Location = new System.Drawing.Point(17, 138);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 14);
            this.label8.TabIndex = 13;
            this.label8.Text = "Issue Date:";
            // 
            // dgv_receipt
            // 
            this.dgv_receipt.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.dgv_receipt.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_receipt.BackgroundColor = System.Drawing.Color.White;
            this.dgv_receipt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgv_receipt.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(58)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Inter", 6F);
            dataGridViewCellStyle22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_receipt.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle22;
            this.dgv_receipt.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_receipt.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn6});
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle23.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Inter", 6F);
            dataGridViewCellStyle23.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_receipt.DefaultCellStyle = dataGridViewCellStyle23;
            this.dgv_receipt.Location = new System.Drawing.Point(20, 155);
            this.dgv_receipt.Name = "dgv_receipt";
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle24.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Inter", 6F);
            dataGridViewCellStyle24.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_receipt.RowHeadersDefaultCellStyle = dataGridViewCellStyle24;
            this.dgv_receipt.RowHeadersWidth = 25;
            this.dgv_receipt.Size = new System.Drawing.Size(290, 184);
            this.dgv_receipt.TabIndex = 76;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.FillWeight = 135.7303F;
            this.dataGridViewTextBoxColumn2.HeaderText = "Product";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.FillWeight = 80.21391F;
            this.dataGridViewTextBoxColumn3.HeaderText = "Qty";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.FillWeight = 91.15051F;
            this.dataGridViewTextBoxColumn4.HeaderText = "Price";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "Subtotal";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Inter", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.label9.Location = new System.Drawing.Point(17, 342);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(75, 14);
            this.label9.TabIndex = 77;
            this.label9.Text = "Total Amount:";
            // 
            // lbl_receiptTotal
            // 
            this.lbl_receiptTotal.AutoSize = true;
            this.lbl_receiptTotal.BackColor = System.Drawing.Color.White;
            this.lbl_receiptTotal.Font = new System.Drawing.Font("Inter", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_receiptTotal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lbl_receiptTotal.Location = new System.Drawing.Point(117, 342);
            this.lbl_receiptTotal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_receiptTotal.Name = "lbl_receiptTotal";
            this.lbl_receiptTotal.Size = new System.Drawing.Size(22, 14);
            this.lbl_receiptTotal.TabIndex = 78;
            this.lbl_receiptTotal.Text = "---";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Inter", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.label11.Location = new System.Drawing.Point(17, 356);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(95, 14);
            this.label11.TabIndex = 79;
            this.label11.Text = "Amount Tendered:";
            // 
            // btnNewTransc
            // 
            this.btnNewTransc.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnNewTransc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.btnNewTransc.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(41)))), ((int)(((byte)(48)))));
            this.btnNewTransc.FlatAppearance.BorderSize = 0;
            this.btnNewTransc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNewTransc.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewTransc.ForeColor = System.Drawing.Color.White;
            this.btnNewTransc.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNewTransc.Location = new System.Drawing.Point(19, 402);
            this.btnNewTransc.Name = "btnNewTransc";
            this.btnNewTransc.Size = new System.Drawing.Size(290, 35);
            this.btnNewTransc.TabIndex = 51;
            this.btnNewTransc.Text = "Start New Transaction";
            this.btnNewTransc.UseVisualStyleBackColor = false;
            this.btnNewTransc.Click += new System.EventHandler(this.btnNewTransc_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Inter", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.label12.Location = new System.Drawing.Point(17, 370);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(47, 14);
            this.label12.TabIndex = 80;
            this.label12.Text = "Change:";
            // 
            // lbl_receiptAmountTendered
            // 
            this.lbl_receiptAmountTendered.AutoSize = true;
            this.lbl_receiptAmountTendered.BackColor = System.Drawing.Color.White;
            this.lbl_receiptAmountTendered.Font = new System.Drawing.Font("Inter", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_receiptAmountTendered.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lbl_receiptAmountTendered.Location = new System.Drawing.Point(117, 356);
            this.lbl_receiptAmountTendered.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_receiptAmountTendered.Name = "lbl_receiptAmountTendered";
            this.lbl_receiptAmountTendered.Size = new System.Drawing.Size(22, 14);
            this.lbl_receiptAmountTendered.TabIndex = 81;
            this.lbl_receiptAmountTendered.Text = "---";
            // 
            // lbl_receiptChanged
            // 
            this.lbl_receiptChanged.AutoSize = true;
            this.lbl_receiptChanged.BackColor = System.Drawing.Color.White;
            this.lbl_receiptChanged.Font = new System.Drawing.Font("Inter", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_receiptChanged.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lbl_receiptChanged.Location = new System.Drawing.Point(117, 370);
            this.lbl_receiptChanged.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_receiptChanged.Name = "lbl_receiptChanged";
            this.lbl_receiptChanged.Size = new System.Drawing.Size(22, 14);
            this.lbl_receiptChanged.TabIndex = 82;
            this.lbl_receiptChanged.Text = "---";
            // 
            // pnlReceipt
            // 
            this.pnlReceipt.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlReceipt.BackColor = System.Drawing.Color.White;
            this.pnlReceipt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlReceipt.Controls.Add(this.lbl_date);
            this.pnlReceipt.Controls.Add(this.lbl_userID);
            this.pnlReceipt.Controls.Add(this.lbl_transactionNumber);
            this.pnlReceipt.Controls.Add(this.lbl_receiptChanged);
            this.pnlReceipt.Controls.Add(this.lbl_receiptAmountTendered);
            this.pnlReceipt.Controls.Add(this.label12);
            this.pnlReceipt.Controls.Add(this.btnNewTransc);
            this.pnlReceipt.Controls.Add(this.label11);
            this.pnlReceipt.Controls.Add(this.lbl_receiptTotal);
            this.pnlReceipt.Controls.Add(this.label9);
            this.pnlReceipt.Controls.Add(this.dgv_receipt);
            this.pnlReceipt.Controls.Add(this.label8);
            this.pnlReceipt.Controls.Add(this.label7);
            this.pnlReceipt.Controls.Add(this.label6);
            this.pnlReceipt.Controls.Add(this.label5);
            this.pnlReceipt.Controls.Add(this.label4);
            this.pnlReceipt.Controls.Add(this.label1);
            this.pnlReceipt.Controls.Add(this.label3);
            this.pnlReceipt.Controls.Add(this.label2);
            this.pnlReceipt.Location = new System.Drawing.Point(279, 39);
            this.pnlReceipt.Name = "pnlReceipt";
            this.pnlReceipt.Size = new System.Drawing.Size(331, 449);
            this.pnlReceipt.TabIndex = 77;
            this.pnlReceipt.Visible = false;
            // 
            // lbl_date
            // 
            this.lbl_date.AutoSize = true;
            this.lbl_date.Font = new System.Drawing.Font("Inter", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_date.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lbl_date.Location = new System.Drawing.Point(73, 138);
            this.lbl_date.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_date.Name = "lbl_date";
            this.lbl_date.Size = new System.Drawing.Size(17, 14);
            this.lbl_date.TabIndex = 85;
            this.lbl_date.Text = "--";
            // 
            // lbl_userID
            // 
            this.lbl_userID.AutoSize = true;
            this.lbl_userID.Font = new System.Drawing.Font("Inter", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_userID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lbl_userID.Location = new System.Drawing.Point(70, 102);
            this.lbl_userID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_userID.Name = "lbl_userID";
            this.lbl_userID.Size = new System.Drawing.Size(17, 14);
            this.lbl_userID.TabIndex = 84;
            this.lbl_userID.Text = "--";
            this.lbl_userID.Click += new System.EventHandler(this.lbl_userID_Click);
            // 
            // lbl_transactionNumber
            // 
            this.lbl_transactionNumber.AutoSize = true;
            this.lbl_transactionNumber.Font = new System.Drawing.Font("Inter", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_transactionNumber.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lbl_transactionNumber.Location = new System.Drawing.Point(98, 88);
            this.lbl_transactionNumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_transactionNumber.Name = "lbl_transactionNumber";
            this.lbl_transactionNumber.Size = new System.Drawing.Size(17, 14);
            this.lbl_transactionNumber.TabIndex = 83;
            this.lbl_transactionNumber.Text = "--";
            // 
            // btn_All
            // 
            this.btn_All.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(170)))), ((int)(((byte)(107)))));
            this.btn_All.FlatAppearance.BorderSize = 0;
            this.btn_All.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(190)))), ((int)(((byte)(127)))));
            this.btn_All.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_All.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_All.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.btn_All.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_All.Location = new System.Drawing.Point(360, 98);
            this.btn_All.Name = "btn_All";
            this.btn_All.Size = new System.Drawing.Size(78, 57);
            this.btn_All.TabIndex = 78;
            this.btn_All.Text = "All";
            this.btn_All.UseVisualStyleBackColor = false;
            this.btn_All.Click += new System.EventHandler(this.btn_All_Click);
            // 
            // POS_System
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(830, 529);
            this.Controls.Add(this.pnlReceipt);
            this.Controls.Add(this.btn_All);
            this.Controls.Add(this.btn_void);
            this.Controls.Add(this.flowpnlProducts);
            this.Controls.Add(this.btnSnacks);
            this.Controls.Add(this.btnDrinks);
            this.Controls.Add(this.pnlItems);
            this.Controls.Add(this.btnFood);
            this.Controls.Add(this.btnMeat);
            this.Controls.Add(this.lblCategoryHeader);
            this.Controls.Add(this.lblItemID_);
            this.Controls.Add(this.lblItemId);
            this.Controls.Add(this.lblItemDetail);
            this.Controls.Add(this.lblHeader);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "POS_System";
            this.Text = "POS_System";
            this.Load += new System.EventHandler(this.POS_System_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvProducts)).EndInit();
            this.pnlItems.ResumeLayout(false);
            this.pnlItems.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_receipt)).EndInit();
            this.pnlReceipt.ResumeLayout(false);
            this.pnlReceipt.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnSaveReceipt;
        private System.Windows.Forms.DataGridView dgvProducts;
        private System.Windows.Forms.Button btnMeat;
        private System.Windows.Forms.Label lblHeader;
        private System.Windows.Forms.Label lblCategoryHeader;
        private System.Windows.Forms.Label lblItemsHeader;
        private System.Windows.Forms.Button btnFood;
        private System.Windows.Forms.Button btnDrinks;
        private System.Windows.Forms.Button btnSnacks;
        private System.Windows.Forms.FlowLayoutPanel flowpnlProducts;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label lblCash;
        private System.Windows.Forms.Label lblChange;
        private System.Windows.Forms.Label lblItemDetail;
        private System.Windows.Forms.Label lblItemId;
        private System.Windows.Forms.Label lblItemID_;
        private System.Windows.Forms.Panel pnlItems;
        private System.Windows.Forms.TextBox txtPaidInCash;
        private System.Windows.Forms.Label lbl_total;
        private System.Windows.Forms.Label lblChangeAmt;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmn_Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmn_Product;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmn_Qty;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmn_Price;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmn_Category;
        private System.Windows.Forms.DataGridViewTextBoxColumn Subtotal;
        private System.Windows.Forms.Button btn_void;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridView dgv_receipt;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lbl_receiptTotal;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnNewTransc;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lbl_receiptAmountTendered;
        private System.Windows.Forms.Label lbl_receiptChanged;
        private System.Windows.Forms.Panel pnlReceipt;
        private System.Windows.Forms.Button btn_All;
        private System.Windows.Forms.Label lbl_date;
        private System.Windows.Forms.Label lbl_userID;
        private System.Windows.Forms.Label lbl_transactionNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
    }
}