﻿namespace POS_System
{
    partial class ProductMngmntChild
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_search = new System.Windows.Forms.TextBox();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.lbl_displayError = new System.Windows.Forms.Label();
            this.cmbSelection = new System.Windows.Forms.ComboBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnHide = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.lblPrice = new System.Windows.Forms.Label();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.btnAddItem = new System.Windows.Forms.Button();
            this.txtItemName = new System.Windows.Forms.TextBox();
            this.lblitemName = new System.Windows.Forms.Label();
            this.lblImage = new System.Windows.Forms.Label();
            this.lbltitle = new System.Windows.Forms.Label();
            this.pnlInventoryItem = new System.Windows.Forms.Panel();
            this.lbldot = new System.Windows.Forms.Label();
            this.lblCategory = new System.Windows.Forms.Label();
            this.cmb_category = new System.Windows.Forms.ComboBox();
            this.rtb_description = new System.Windows.Forms.RichTextBox();
            this.lblDesctiption = new System.Windows.Forms.Label();
            this.btnUpload = new System.Windows.Forms.Button();
            this.pbAddItem = new System.Windows.Forms.PictureBox();
            this.btnEditSave = new System.Windows.Forms.Button();
            this.flowpnlBg = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlTop.SuspendLayout();
            this.pnlBottom.SuspendLayout();
            this.pnlInventoryItem.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbAddItem)).BeginInit();
            this.SuspendLayout();
            // 
            // tb_search
            // 
            this.tb_search.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_search.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_search.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.tb_search.Location = new System.Drawing.Point(439, 7);
            this.tb_search.Name = "tb_search";
            this.tb_search.Size = new System.Drawing.Size(223, 22);
            this.tb_search.TabIndex = 61;
            this.tb_search.TextChanged += new System.EventHandler(this.tb_search_TextChanged);
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.White;
            this.pnlTop.Controls.Add(this.lbl_displayError);
            this.pnlTop.Controls.Add(this.cmbSelection);
            this.pnlTop.Controls.Add(this.btnSearch);
            this.pnlTop.Controls.Add(this.tb_search);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(697, 49);
            this.pnlTop.TabIndex = 18;
            // 
            // lbl_displayError
            // 
            this.lbl_displayError.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_displayError.AutoSize = true;
            this.lbl_displayError.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_displayError.ForeColor = System.Drawing.Color.Firebrick;
            this.lbl_displayError.Location = new System.Drawing.Point(555, 33);
            this.lbl_displayError.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_displayError.Name = "lbl_displayError";
            this.lbl_displayError.Size = new System.Drawing.Size(107, 16);
            this.lbl_displayError.TabIndex = 68;
            this.lbl_displayError.Text = "Item does not exist";
            this.lbl_displayError.Visible = false;
            // 
            // cmbSelection
            // 
            this.cmbSelection.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(247)))), ((int)(((byte)(248)))));
            this.cmbSelection.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSelection.Font = new System.Drawing.Font("Inter", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSelection.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(52)))), ((int)(((byte)(52)))));
            this.cmbSelection.FormattingEnabled = true;
            this.cmbSelection.Items.AddRange(new object[] {
            "All",
            "Food",
            "Meat",
            "Drinks",
            "Snacks"});
            this.cmbSelection.Location = new System.Drawing.Point(96, 2);
            this.cmbSelection.Name = "cmbSelection";
            this.cmbSelection.Size = new System.Drawing.Size(130, 26);
            this.cmbSelection.TabIndex = 67;
            this.cmbSelection.SelectedIndexChanged += new System.EventHandler(this.cmbSelection_SelectedIndexChanged);
            // 
            // btnSearch
            // 
            this.btnSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSearch.BackColor = System.Drawing.Color.White;
            this.btnSearch.FlatAppearance.BorderSize = 0;
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.ForeColor = System.Drawing.Color.White;
            this.btnSearch.Image = global::POS_System.Properties.Resources.search__2_;
            this.btnSearch.Location = new System.Drawing.Point(668, 0);
            this.btnSearch.MaximumSize = new System.Drawing.Size(29, 30);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(29, 30);
            this.btnSearch.TabIndex = 62;
            this.btnSearch.UseVisualStyleBackColor = false;
            // 
            // btnHide
            // 
            this.btnHide.FlatAppearance.BorderSize = 0;
            this.btnHide.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHide.Font = new System.Drawing.Font("Inter", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHide.ForeColor = System.Drawing.Color.White;
            this.btnHide.Location = new System.Drawing.Point(336, 8);
            this.btnHide.Name = "btnHide";
            this.btnHide.Size = new System.Drawing.Size(31, 33);
            this.btnHide.TabIndex = 76;
            this.btnHide.Text = "X";
            this.btnHide.UseVisualStyleBackColor = true;
            this.btnHide.Click += new System.EventHandler(this.btnHide_Click_1);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(124)))), ((int)(((byte)(45)))));
            this.btnSave.FlatAppearance.BorderSize = 0;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnSave.Location = new System.Drawing.Point(16, 275);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(327, 32);
            this.btnSave.TabIndex = 1;
            this.btnSave.Text = "Save to Inventory";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // txtPrice
            // 
            this.txtPrice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(247)))), ((int)(((byte)(248)))));
            this.txtPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPrice.Font = new System.Drawing.Font("Inter", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrice.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.txtPrice.Location = new System.Drawing.Point(158, 152);
            this.txtPrice.MaxLength = 12;
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(185, 23);
            this.txtPrice.TabIndex = 75;
            this.txtPrice.Tag = "tb";
            this.txtPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPrice_KeyPress);
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lblPrice.Location = new System.Drawing.Point(156, 133);
            this.lblPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(33, 16);
            this.lblPrice.TabIndex = 74;
            this.lblPrice.Text = "Price";
            // 
            // pnlBottom
            // 
            this.pnlBottom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.pnlBottom.Controls.Add(this.btnAddItem);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 375);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(697, 55);
            this.pnlBottom.TabIndex = 16;
            // 
            // btnAddItem
            // 
            this.btnAddItem.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(182)))), ((int)(((byte)(102)))));
            this.btnAddItem.FlatAppearance.BorderSize = 0;
            this.btnAddItem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddItem.Font = new System.Drawing.Font("Inter", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddItem.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnAddItem.Location = new System.Drawing.Point(550, 8);
            this.btnAddItem.Name = "btnAddItem";
            this.btnAddItem.Size = new System.Drawing.Size(147, 35);
            this.btnAddItem.TabIndex = 0;
            this.btnAddItem.Text = "Add Item";
            this.btnAddItem.UseVisualStyleBackColor = false;
            this.btnAddItem.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // txtItemName
            // 
            this.txtItemName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(247)))), ((int)(((byte)(248)))));
            this.txtItemName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtItemName.Font = new System.Drawing.Font("Inter", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.txtItemName.Location = new System.Drawing.Point(158, 106);
            this.txtItemName.Name = "txtItemName";
            this.txtItemName.Size = new System.Drawing.Size(186, 23);
            this.txtItemName.TabIndex = 71;
            this.txtItemName.Tag = "tb";
            // 
            // lblitemName
            // 
            this.lblitemName.AutoSize = true;
            this.lblitemName.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblitemName.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lblitemName.Location = new System.Drawing.Point(155, 87);
            this.lblitemName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblitemName.Name = "lblitemName";
            this.lblitemName.Size = new System.Drawing.Size(63, 16);
            this.lblitemName.TabIndex = 70;
            this.lblitemName.Text = "Item Name";
            // 
            // lblImage
            // 
            this.lblImage.AutoSize = true;
            this.lblImage.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblImage.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lblImage.Location = new System.Drawing.Point(14, 59);
            this.lblImage.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblImage.Name = "lblImage";
            this.lblImage.Size = new System.Drawing.Size(39, 16);
            this.lblImage.TabIndex = 68;
            this.lblImage.Text = "Image";
            // 
            // lbltitle
            // 
            this.lbltitle.AutoSize = true;
            this.lbltitle.Font = new System.Drawing.Font("Inter", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltitle.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbltitle.Location = new System.Drawing.Point(12, 18);
            this.lbltitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbltitle.Name = "lbltitle";
            this.lbltitle.Size = new System.Drawing.Size(98, 21);
            this.lbltitle.TabIndex = 67;
            this.lbltitle.Text = "Product Item";
            // 
            // pnlInventoryItem
            // 
            this.pnlInventoryItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(61)))), ((int)(((byte)(61)))));
            this.pnlInventoryItem.Controls.Add(this.txtPrice);
            this.pnlInventoryItem.Controls.Add(this.lbldot);
            this.pnlInventoryItem.Controls.Add(this.lblCategory);
            this.pnlInventoryItem.Controls.Add(this.cmb_category);
            this.pnlInventoryItem.Controls.Add(this.rtb_description);
            this.pnlInventoryItem.Controls.Add(this.lblDesctiption);
            this.pnlInventoryItem.Controls.Add(this.btnSave);
            this.pnlInventoryItem.Controls.Add(this.btnUpload);
            this.pnlInventoryItem.Controls.Add(this.pbAddItem);
            this.pnlInventoryItem.Controls.Add(this.btnEditSave);
            this.pnlInventoryItem.Controls.Add(this.btnHide);
            this.pnlInventoryItem.Controls.Add(this.lblPrice);
            this.pnlInventoryItem.Controls.Add(this.txtItemName);
            this.pnlInventoryItem.Controls.Add(this.lblitemName);
            this.pnlInventoryItem.Controls.Add(this.lblImage);
            this.pnlInventoryItem.Controls.Add(this.lbltitle);
            this.pnlInventoryItem.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.pnlInventoryItem.Location = new System.Drawing.Point(160, 40);
            this.pnlInventoryItem.Name = "pnlInventoryItem";
            this.pnlInventoryItem.Size = new System.Drawing.Size(375, 329);
            this.pnlInventoryItem.TabIndex = 17;
            // 
            // lbldot
            // 
            this.lbldot.AutoSize = true;
            this.lbldot.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldot.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbldot.Location = new System.Drawing.Point(281, 154);
            this.lbldot.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbldot.Name = "lbldot";
            this.lbldot.Size = new System.Drawing.Size(10, 16);
            this.lbldot.TabIndex = 88;
            this.lbldot.Text = ".";
            // 
            // lblCategory
            // 
            this.lblCategory.AutoSize = true;
            this.lblCategory.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCategory.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lblCategory.Location = new System.Drawing.Point(156, 40);
            this.lblCategory.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new System.Drawing.Size(55, 16);
            this.lblCategory.TabIndex = 87;
            this.lblCategory.Text = "Category";
            // 
            // cmb_category
            // 
            this.cmb_category.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(247)))), ((int)(((byte)(248)))));
            this.cmb_category.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_category.Font = new System.Drawing.Font("Inter", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_category.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(52)))), ((int)(((byte)(52)))));
            this.cmb_category.FormattingEnabled = true;
            this.cmb_category.Items.AddRange(new object[] {
            "Food",
            "Meat",
            "Drinks",
            "Snacks"});
            this.cmb_category.Location = new System.Drawing.Point(159, 59);
            this.cmb_category.Name = "cmb_category";
            this.cmb_category.Size = new System.Drawing.Size(185, 26);
            this.cmb_category.TabIndex = 68;
            // 
            // rtb_description
            // 
            this.rtb_description.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(247)))), ((int)(((byte)(248)))));
            this.rtb_description.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rtb_description.Font = new System.Drawing.Font("Inter", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtb_description.Location = new System.Drawing.Point(159, 198);
            this.rtb_description.MaxLength = 98;
            this.rtb_description.Name = "rtb_description";
            this.rtb_description.Size = new System.Drawing.Size(184, 64);
            this.rtb_description.TabIndex = 85;
            this.rtb_description.Text = "";
            // 
            // lblDesctiption
            // 
            this.lblDesctiption.AutoSize = true;
            this.lblDesctiption.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDesctiption.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lblDesctiption.Location = new System.Drawing.Point(156, 178);
            this.lblDesctiption.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDesctiption.Name = "lblDesctiption";
            this.lblDesctiption.Size = new System.Drawing.Size(67, 16);
            this.lblDesctiption.TabIndex = 84;
            this.lblDesctiption.Text = "Description";
            // 
            // btnUpload
            // 
            this.btnUpload.BackColor = System.Drawing.Color.Transparent;
            this.btnUpload.FlatAppearance.BorderColor = System.Drawing.Color.Goldenrod;
            this.btnUpload.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpload.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpload.ForeColor = System.Drawing.Color.Goldenrod;
            this.btnUpload.Location = new System.Drawing.Point(17, 170);
            this.btnUpload.Name = "btnUpload";
            this.btnUpload.Size = new System.Drawing.Size(126, 32);
            this.btnUpload.TabIndex = 83;
            this.btnUpload.Text = "Upload";
            this.btnUpload.UseVisualStyleBackColor = false;
            this.btnUpload.Click += new System.EventHandler(this.btnUpload_Click);
            // 
            // pbAddItem
            // 
            this.pbAddItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(247)))), ((int)(((byte)(248)))));
            this.pbAddItem.Location = new System.Drawing.Point(40, 84);
            this.pbAddItem.Name = "pbAddItem";
            this.pbAddItem.Size = new System.Drawing.Size(80, 80);
            this.pbAddItem.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbAddItem.TabIndex = 82;
            this.pbAddItem.TabStop = false;
            // 
            // btnEditSave
            // 
            this.btnEditSave.BackColor = System.Drawing.Color.Goldenrod;
            this.btnEditSave.FlatAppearance.BorderSize = 0;
            this.btnEditSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEditSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditSave.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnEditSave.Location = new System.Drawing.Point(16, 274);
            this.btnEditSave.Name = "btnEditSave";
            this.btnEditSave.Size = new System.Drawing.Size(327, 32);
            this.btnEditSave.TabIndex = 77;
            this.btnEditSave.Text = "Save Changes";
            this.btnEditSave.UseVisualStyleBackColor = false;
            this.btnEditSave.Click += new System.EventHandler(this.btnEditSave_Click);
            // 
            // flowpnlBg
            // 
            this.flowpnlBg.AutoScroll = true;
            this.flowpnlBg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(241)))), ((int)(((byte)(241)))));
            this.flowpnlBg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowpnlBg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowpnlBg.Location = new System.Drawing.Point(0, 49);
            this.flowpnlBg.Name = "flowpnlBg";
            this.flowpnlBg.Padding = new System.Windows.Forms.Padding(14, 12, 11, 12);
            this.flowpnlBg.Size = new System.Drawing.Size(697, 326);
            this.flowpnlBg.TabIndex = 19;
            // 
            // ProductMngmntChild
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ClientSize = new System.Drawing.Size(697, 430);
            this.Controls.Add(this.pnlInventoryItem);
            this.Controls.Add(this.flowpnlBg);
            this.Controls.Add(this.pnlTop);
            this.Controls.Add(this.pnlBottom);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ProductMngmntChild";
            this.Text = "addonsForm";
            this.Load += new System.EventHandler(this.addonsForm_Load);
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.pnlBottom.ResumeLayout(false);
            this.pnlInventoryItem.ResumeLayout(false);
            this.pnlInventoryItem.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbAddItem)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox tb_search;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnHide;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Button btnAddItem;
        private System.Windows.Forms.TextBox txtItemName;
        private System.Windows.Forms.Label lblitemName;
        private System.Windows.Forms.Label lblImage;
        private System.Windows.Forms.Label lbltitle;
        private System.Windows.Forms.Panel pnlInventoryItem;
        private System.Windows.Forms.FlowLayoutPanel flowpnlBg;
        private System.Windows.Forms.Button btnEditSave;
        private System.Windows.Forms.Button btnUpload;
        private System.Windows.Forms.PictureBox pbAddItem;
        private System.Windows.Forms.RichTextBox rtb_description;
        private System.Windows.Forms.Label lblDesctiption;
        private System.Windows.Forms.ComboBox cmbSelection;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.ComboBox cmb_category;
        private System.Windows.Forms.Label lbldot;
        private System.Windows.Forms.Label lbl_displayError;
    }
}